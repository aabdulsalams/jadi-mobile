package com.capstone.jadi.utils

object   UiConstValue {

    const val LOADING_TIME = 1500L
    const val ACTION_DELAYED_TIME = 1000L

}