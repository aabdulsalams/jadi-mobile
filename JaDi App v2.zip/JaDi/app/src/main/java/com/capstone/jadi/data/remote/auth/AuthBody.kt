package com.capstone.jadi.data.remote.auth

data class AuthBody(
    val username: String,
    val email: String,
    val password: String
)
